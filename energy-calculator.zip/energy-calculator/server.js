const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();
const port = 3001;

// MySQL connection setup
const db = mysql.createConnection({
    host: '127.0.0.1', // or 'localhost'
    user: 'root',
    password: 'm,3H9:WpQSX9Ka', // Replace with your MySQL root password
    database: 'energy_db'
});

// Connect to MySQL
db.connect(err => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the database');
});

app.use(bodyParser.json());

// Endpoint to post energy usage data
app.post('/api/energy', (req, res) => {
    let data = { user_id: req.body.user_id, hoursUsed: req.body.hoursUsed, wattage: req.body.wattage, energyUsed: req.body.energyUsed, cost: req.body.cost };
    let sql = 'INSERT INTO EnergyCalculations SET ?';
    db.query(sql, data, (err, results) => {
        if (err) {
            console.error('Error inserting data:', err);
            res.status(500).send(err);
            return;
        }
        res.send({
            status: 'Data saved',
            id: results.insertId
        });
    });
});

// Endpoint to retrieve energy usage data
app.get('/api/energy', (req, res) => {
    let sql = 'SELECT * FROM EnergyCalculations';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error retrieving data:', err);
            res.status(500).send(err);
            return;
        }
        res.send(results);
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
