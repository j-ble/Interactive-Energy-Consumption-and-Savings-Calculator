function calculateEnergy() {
    var hours = $('#hoursUsed').val();
    var wattage = $('#wattage').val();
    if (hours && wattage) {
        var energyUsed = (hours * wattage) / 1000; // kWh
        var costPerKwh = 0.16; // Example cost per kWh
        var cost = energyUsed * costPerKwh;
        $('#result').html(`Total energy used: ${energyUsed.toFixed(2)} kWh<br>Total cost: $${cost.toFixed(2)}`);
    } else {
        $('#result').html("Please enter all values.");
    }
}
